import { type ChangeEvent, type FormEvent, type ReactNode, useEffect, useMemo, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { ClerkProvider, Show, SignIn as ClerkSignIn, SignUp as ClerkSignUp, useAuth, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  ArrowUpRight,
  BarChart3,
  Bell,
  ChevronRight,
  CircleHelp,
  ClipboardList,
  Clock3,
  Database,
  FileSearch,
  FileText,
  Globe2,
  Inbox,
  Laptop2,
  Link2,
  LockKeyhole,
  LogOut,
  Mail,
  Menu,
  Network,
  Plus,
  RefreshCw,
  Search,
  Send,
  Settings,
  ShieldCheck,
  ShieldAlert,
  SlidersHorizontal,
  Trash2,
  Upload,
  UserRound,
  Users,
  X,
} from 'lucide-react';
import {
  getGetAnalysisJobQueryKey,
  getGetForensicReportQueryKey,
  getGetInvestigationQueryKey,
  getGetThreadQueryKey,
  getListInvestigationsQueryKey,
  getSearchIntelligenceQueryKey,
  useAnalyzeEmails,
  useCreateInvestigation,
  useDeleteInvestigation,
  useGetAnalysisJob,
  useGetForensicReport,
  useGetDashboardSummary,
  useGetInvestigation,
  useGetThread,
  useListInvestigations,
  useListSessions,
  useListThreads,
  useSearchIntelligence,
  useRequestUploadUrl,
} from '@workspace/api-client-react';
import type {
  AnalysisJob,
  Confidence,
  DashboardSummary,
  Evidence,
  EmailRecord,
  ForensicReport,
  Investigation,
  InvestigationDetail,
  LoginSession,
  SearchResult,
  Thread,
  ThreadDetail,
} from '@workspace/api-client-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Link, Redirect, Route, Router as WouterRouter, Switch, useLocation, useParams } from 'wouter';

const queryClient = new QueryClient();
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');

function stripBase(path: string) {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || '/'
    : path;
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: 'hsl(167 82% 44%)',
    colorForeground: 'hsl(214 35% 14%)',
    colorMutedForeground: 'hsl(215 18% 44%)',
    colorDanger: 'hsl(0 72% 52%)',
    colorBackground: 'hsl(210 33% 98%)',
    colorInput: 'hsl(210 25% 96%)',
    colorInputForeground: 'hsl(214 35% 14%)',
    colorNeutral: 'hsl(214 20% 82%)',
    fontFamily: 'DM Sans, sans-serif',
    borderRadius: '0.55rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-white rounded-2xl w-[440px] max-w-full overflow-hidden',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-slate-900',
    headerSubtitle: 'text-slate-600',
    socialButtonsBlockButtonText: 'text-slate-800',
    formFieldLabel: 'text-slate-800',
    footerActionLink: 'text-teal-700',
    footerActionText: 'text-slate-600',
    dividerText: 'text-slate-500',
    identityPreviewEditButton: 'text-teal-700',
    formFieldSuccessText: 'text-emerald-700',
    alertText: 'text-red-700',
    logoBox: 'mb-4',
    logoImage: 'h-8',
    socialButtonsBlockButton: 'border-slate-200 bg-white',
    formButtonPrimary: 'bg-teal-600 hover:bg-teal-700',
    formFieldInput: 'border-slate-200 bg-slate-50 text-slate-900',
    footerAction: 'border-slate-200',
    dividerLine: 'bg-slate-200',
    alert: 'bg-red-50 border-red-200',
    otpCodeFieldInput: 'border-slate-200 bg-slate-50',
    formFieldRow: 'gap-2',
    main: 'bg-transparent',
  },
};

const navItems = [
  { href: '/user-portal', label: 'Overview', icon: BarChart3 },
  { href: '/investigations', label: 'Investigations', icon: ClipboardList },
  { href: '/threads', label: 'Threads', icon: Network },
  { href: '/analyze', label: 'Analyze', icon: Upload },
  { href: '/search', label: 'Intelligence search', icon: Search },
];

function cx(...values: Array<string | false | null | undefined>) {
  return values.filter(Boolean).join(' ');
}

function formatDate(value?: string) {
  if (!value) return '—';
  const date = new Date(value);
  return Number.isNaN(date.valueOf()) ? value : date.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function pct(value?: number) {
  return `${Math.round((value ?? 0) * 100)}%`;
}

function riskClass(zone?: string) {
  if (zone === 'dangerous') return 'dangerous';
  if (zone === 'uncertain' || zone === 'needs_review') return 'uncertain';
  if (zone === 'processing') return 'processing';
  return 'safe';
}

function Logo({ inverse = false }: { inverse?: boolean }) {
  return (
    <div className="brand" style={inverse ? { border: 0, padding: 0 } : undefined}>
      <div className="brand-mark"><Activity size={17} strokeWidth={2.5} /></div>
      <div className="brand-copy">
        <div className="brand-name">MailTrace AI</div>
        <div className="brand-sub">forensic workspace</div>
      </div>
    </div>
  );
}

function StatusChip({ value, label }: { value?: string; label?: string }) {
  return <span className={cx('status', riskClass(value))}>{label ?? (value ?? 'unknown').replaceAll('_', ' ')}</span>;
}

function ConfidenceCell({ confidence }: { confidence?: Confidence | number }) {
  const score = typeof confidence === 'number' ? confidence : confidence?.score;
  const lower = typeof confidence === 'number' ? undefined : confidence?.lowerBound;
  const upper = typeof confidence === 'number' ? undefined : confidence?.upperBound;
  return (
    <div className="confidence" data-testid="confidence-cell">
      <span>{pct(score)}</span>
      <span className="confidence-track"><span className="confidence-fill" style={{ width: `${Math.round((score ?? 0) * 100)}%` }} /></span>
      {lower !== undefined && upper !== undefined ? <span className="confidence-interval">[{pct(lower)}–{pct(upper)}]</span> : null}
    </div>
  );
}

function EvidenceList({ evidence }: { evidence?: Evidence[] }) {
  if (!evidence?.length) return <div className="empty" style={{ padding: '25px 10px' }}><strong>No evidence recorded</strong><span>Signals will appear when the model has supporting context.</span></div>;
  return (
    <div className="evidence-list">
      {evidence.map((item, index) => (
        <div className={cx('evidence', item.signal === 'negative' && 'warn', item.signal === 'positive' && 'danger')} key={`${item.label}-${index}`} data-testid={`evidence-${index}`}>
          <div className="evidence-head"><span>{item.label}</span><span className="evidence-weight">{Math.round(item.weight * 100)}% weight</span></div>
          <div className="evidence-detail">{item.detail}</div>
        </div>
      ))}
    </div>
  );
}

function StoredEmailsCard({ emails }: { emails: EmailRecord[] }) {
  return <div className="card card-pad" style={{ marginTop: 14 }}><div className="section-head"><span className="section-title">Stored emails</span><span className="section-meta">{emails.length} messages</span></div>{emails.length ? <div className="table-wrap"><table className="data-table"><thead><tr><th>Sender</th><th>Subject</th><th>Risk</th><th>Indicators</th></tr></thead><tbody>{emails.map((email) => <tr key={email.id}><td><strong>{email.sender}</strong><span className="subline">{email.recipients?.join(', ') || 'No recipient parsed'}</span></td><td><strong>{email.subject}</strong><span className="subline">{formatDate(email.timestamp)}</span></td><td><StatusChip value={email.riskZone} /><span className="subline">{email.riskScore}/100</span></td><td><span className="mono">{email.evidence.length} signals</span><span className="subline">{email.urls?.length ?? 0} URLs · {email.ips?.length ?? 0} IPs</span></td></tr>)}</tbody></table></div> : <EmptyState icon={Mail} title="No stored emails" copy="Uploaded messages will appear here after analysis." />}</div>;
}

function TestGeolocationCard({ emails }: { emails: Array<{ ips?: string[] }> }) {
  const ips = Array.from(new Set(emails.flatMap((email) => email.ips ?? [])));
  const locations = ['Bengaluru, India', 'Amsterdam, Netherlands', 'Ashburn, United States'];
  return <div className="card card-pad" style={{ marginTop: 14 }}><div className="section-head"><span className="section-title">Geolocation test</span><span className="section-meta">filler data</span></div><p className="page-note" style={{ marginTop: 0 }}>Test-only locations from extracted IP indicators. No external lookup is running.</p>{ips.length ? <div className="signal-stack">{ips.map((ip, index) => <div className="signal-row" key={ip}><span className="signal-label"><Globe2 size={14} />{ip}</span><span className="section-meta">{locations[index % locations.length]}</span></div>)}</div> : <EmptyState icon={Globe2} title="No IP indicators" copy="The uploaded messages did not include an IP address." />}</div>;
}

function LoadingCard({ rows = 4 }: { rows?: number }) {
  return <div className="card card-pad" data-testid="loading-state"><div className="skeleton" style={{ width: '26%', marginBottom: 18 }} />{Array.from({ length: rows }).map((_, index) => <div className="skeleton" style={{ width: `${68 + (index % 3) * 9}%`, margin: '13px 0' }} key={index} />)}</div>;
}

function ErrorState({ onRetry }: { onRetry?: () => void }) {
  return <div className="card error-state" data-testid="error-state"><AlertTriangle size={21} /><div style={{ marginTop: 8 }}>Signal unavailable</div><p style={{ color: 'hsl(var(--muted-foreground))', fontSize: 12 }}>The workspace could not retrieve this slice of intelligence.</p>{onRetry ? <button className="btn btn-ghost" onClick={onRetry} data-testid="button-retry">Retry query</button> : null}</div>;
}

function EmptyState({ icon: Icon = Inbox, title, copy, action }: { icon?: typeof Inbox; title: string; copy: string; action?: ReactNode }) {
  return <div className="empty" data-testid="empty-state"><div className="empty-icon"><Icon size={18} /></div><strong>{title}</strong><span>{copy}</span>{action ? <div style={{ marginTop: 16 }}>{action}</div> : null}</div>;
}

function Shell({ children }: { children: ReactNode }) {
  const [location, setLocation] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const active = location === '/' ? '/user-portal' : location.split('/').slice(0, 2).join('/');
  const { signOut: clerkSignOut } = useClerk();
  const signOut = () => { void clerkSignOut({ redirectUrl: basePath || '/' }); setLocation('/'); };
  return (
    <div className="app-shell">
      <aside className={cx('sidebar', mobileOpen && 'mobile-open')}>
        <Logo />
        <div className="nav-label">Workspace</div>
        <nav className="nav">
          {navItems.map(({ href, label, icon: Icon }) => <Link href={href} className={cx('nav-link', active === href || (href !== '/user-portal' && active.startsWith(href)) ? 'active' : '')} onClick={() => setMobileOpen(false)} data-testid={`link-nav-${label.toLowerCase().replaceAll(' ', '-')}`} key={href}><Icon size={16} /><span>{label}</span></Link>)}
        </nav>
        <div className="nav-label">Account</div>
        <nav className="nav">
          <Link href="/sessions" className={cx('nav-link', active === '/sessions' && 'active')} data-testid="link-nav-sessions"><Clock3 size={16} /><span>Sessions</span></Link>
          <Link href="/settings" className={cx('nav-link', active === '/settings' && 'active')} data-testid="link-nav-settings"><Settings size={16} /><span>Settings</span></Link>
        </nav>
        <div className="sidebar-footer">
          <div className="analyst-card"><div className="avatar">MA</div><div><div className="analyst-name">M. Analyst</div><div className="analyst-role">security operations</div></div></div>
          <button className="nav-link" style={{ width: '100%', border: 0, background: 'transparent' }} onClick={signOut} data-testid="button-sign-out"><LogOut size={16} /><span>Sign out</span></button>
        </div>
      </aside>
      <section className="workspace">
        <header className="topbar">
          <div className="crumb"><button className="icon-btn mobile-only" onClick={() => setMobileOpen(!mobileOpen)} data-testid="button-mobile-menu"><Menu size={16} /></button><span className="mono">MAILTRACE /</span><strong>{active === '/user-portal' ? 'overview' : active.replace('/', '')}</strong></div>
          <div className="top-actions"><span className="status safe">live index</span><button className="icon-btn" title="Notifications" data-testid="button-notifications"><Bell size={15} /></button><Link href="/analyze" className="btn btn-primary" data-testid="link-quick-analyze"><Plus size={14} /> New analysis</Link></div>
        </header>
        {children}
      </section>
    </div>
  );
}

function Protected({ children }: { children: ReactNode }) {
  const { isLoaded, isSignedIn } = useAuth();
  if (!isLoaded) return <div className="auth-page"><LoadingCard rows={3} /></div>;
  return isSignedIn ? <Shell>{children}</Shell> : <Redirect to="/sign-in" />;
}

function PublicHome() {
  const { isLoaded, isSignedIn } = useAuth();
  if (isLoaded && isSignedIn) return <Redirect to="/user-portal" />;
  const bars = [36, 62, 47, 82, 58, 74, 94, 66, 78, 53, 87, 70, 96, 71];
  return (
    <div className="landing">
      <nav className="landing-nav">
        <Logo />
        <div className="landing-links"><a href="#method" data-testid="link-method">Method</a><Link href="/sign-in" data-testid="link-landing-sign-in">Sign in</Link><Link href="/sign-up" className="btn btn-primary" data-testid="link-landing-sign-up">Request access</Link></div>
      </nav>
      <main>
        <section className="landing-hero">
          <div>
            <span className="landing-kicker"><span style={{ width: 6, height: 6, background: 'currentColor', borderRadius: '50%' }} /> explainable email intelligence</span>
            <h1>See the thread.<br /><em>Know the signal.</em></h1>
            <p className="landing-lead">MailTrace AI reconstructs fragmented email conversations and surfaces the evidence behind every risk decision — without pretending the uncertain parts are certain.</p>
            <div className="landing-cta"><Link href="/sign-up" className="btn btn-primary" data-testid="link-hero-start">Start an investigation <ChevronRight size={15} /></Link><a href="#method" className="btn btn-ghost" data-testid="link-hero-method">How it works</a></div>
            <div className="landing-note">Built for analysts who need the why, not just the verdict.</div>
          </div>
          <div className="landing-console" aria-label="MailTrace analysis preview">
            <div className="console-top"><span>INVESTIGATION / MT-0428</span><span className="console-status"><i />INDEXED</span></div>
            <div className="console-main"><div className="console-heading"><strong>Conversation topology</strong><span>last 30 days</span></div><div className="console-bars">{bars.map((bar, i) => <div className="console-bar" style={{ height: `${bar}%` }} key={i} />)}</div><div className="console-readout"><div><b>18</b><span>messages</span></div><div><b>04</b><span>participants</span></div><div><b>0.84</b><span>confidence</span></div></div></div>
          </div>
        </section>
        <section className="landing-section" id="method"><div className="landing-section-inner"><div className="eyebrow">The analyst loop</div><h2 className="page-title" style={{ maxWidth: 590 }}>From raw mail to a defensible read.</h2><div className="feature-grid" style={{ marginTop: 28 }}><div className="feature"><ShieldCheck className="feature-icon" size={20} /><h3>Decisions with receipts</h3><p>Every thread decision is paired with itemized signals, model weight, and a confidence interval. Nothing is a black box.</p></div><div className="feature"><Network className="feature-icon" size={20} /><h3>Reconstruct context</h3><p>Follow participants, subjects, domains, and message timing across fragmented mailboxes.</p></div><div className="feature"><AlertTriangle className="feature-icon" size={20} /><h3>Respect uncertainty</h3><p>Ambiguous relationships stay visibly distinct from safe and dangerous findings.</p></div></div></div></section>
      </main>
      <footer className="landing-foot"><span>MAILTRACE AI / 2025</span><span>EXPLAINABILITY OVER HYPE</span></footer>
    </div>
  );
}

function SignIn({ signUp = false }: { signUp?: boolean }) {
  const [, setLocation] = useLocation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const submit = (event: FormEvent) => { event.preventDefault(); localStorage.setItem('mailtrace-auth', '1'); setLocation('/user-portal'); };
  return (
    <div className="auth-page"><div className="auth-card"><div className="auth-brand"><div className="brand-mark"><Activity size={17} /></div><div><div className="brand-name">MailTrace AI</div><div className="brand-sub" style={{ color: 'hsl(var(--muted-foreground))' }}>forensic workspace</div></div></div><h1 className="auth-title">{signUp ? 'Create your analyst account' : 'Welcome back, analyst'}</h1><p className="auth-copy">{signUp ? 'Set up a secure workspace for explainable email investigations.' : 'Sign in to continue reconstructing the signal.'}</p><form onSubmit={submit}><div className="form-field"><label htmlFor="auth-email">Work email</label><input id="auth-email" type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="analyst@company.com" data-testid="input-auth-email" /></div><div className="form-field"><label htmlFor="auth-password">Password</label><input id="auth-password" type="password" required value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" data-testid="input-auth-password" /></div><button className="btn btn-primary auth-submit" type="submit" data-testid="button-auth-submit">{signUp ? 'Create workspace' : 'Sign in to workspace'} <ArrowUpRight size={14} /></button></form><p className="auth-switch">{signUp ? 'Already have an account? ' : 'New to MailTrace? '}<Link href={signUp ? '/sign-in' : '/sign-up'} data-testid="link-auth-switch">{signUp ? 'Sign in' : 'Request access'}</Link></p><p className="auth-switch" style={{ marginTop: 10, fontSize: 10 }}>Protected with your organization’s identity provider.</p></div></div>
  );
}

function ClerkSignInPage() {
  return <div className="auth-page"><ClerkSignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} /></div>;
}

function ClerkSignUpPage() {
  return <div className="auth-page"><ClerkSignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} /></div>;
}

function Dashboard() {
  const summaryQuery = useGetDashboardSummary();
  const investigationsQuery = useListInvestigations({ limit: 5 });
  const summary = summaryQuery.data as DashboardSummary | undefined;
  const investigations = investigationsQuery.data as Investigation[] | undefined;
  if (summaryQuery.isLoading) return <main className="main"><LoadingCard rows={6} /></main>;
  if (summaryQuery.isError) return <main className="main"><ErrorState onRetry={() => summaryQuery.refetch()} /></main>;
  const trend = summary?.trend ?? [];
  return <main className="main"><div className="page-head"><div><div className="eyebrow">Operations / 08:42 UTC</div><h1 className="page-title">Good morning, analyst.</h1><p className="page-note">A measured view of what your mail index knows today. Start with the anomalies, then follow the evidence.</p></div><Link href="/analyze" className="btn btn-primary" data-testid="link-dashboard-analyze"><Upload size={14} /> Analyze email</Link></div>
    <div className="metrics-grid">{[['Emails analyzed', summary?.emailsAnalyzed ?? 0, 'indexed records'], ['Threads detected', summary?.threadsDetected ?? 0, 'conversation groups'], ['Dangerous', summary?.dangerousCount ?? 0, 'requires attention'], ['Uncertain', summary?.uncertainCount ?? 0, 'needs analyst read']].map(([label, value, detail], index) => <div className="card metric" key={String(label)} data-testid={`metric-${index}`}><div className="metric-label">{label}</div><div className="metric-value">{value}</div><div className={cx('metric-detail', index === 2 ? 'warn' : index === 1 ? 'good' : '')}>{index === 2 ? <ArrowUpRight size={12} /> : <Activity size={12} />}{detail}</div></div>)}</div>
    <div className="dashboard-grid"><div className="card card-pad"><div className="section-head"><span className="section-title">Index activity</span><span className="section-meta">emails / threads</span></div><div className="trend-chart">{trend.length ? trend.map((point, index) => { const max = Math.max(...trend.map(item => Math.max(item.emails, item.threads)), 1); return <div className="trend-col" key={`${point.label}-${index}`}><span className="trend-bar" style={{ height: `${Math.max(8, point.emails / max * 100)}%` }} /><span className="trend-bar secondary" style={{ height: `${Math.max(8, point.threads / max * 100)}%` }} /><span className="trend-label">{point.label}</span></div>; }) : <EmptyState icon={Activity} title="No activity yet" copy="Trend data will render after the first analysis." />}</div></div><div className="card card-pad"><div className="section-head"><span className="section-title">Risk surface</span><span className="section-meta">current index</span></div><div className="signal-stack"><div className="signal-row"><span className="signal-label"><i className="signal-dot red" />Dangerous mail</span><span className="signal-value">{summary?.dangerousCount ?? 0}</span></div><div className="signal-row"><span className="signal-label"><i className="signal-dot orange" />Suspicious URLs</span><span className="signal-value">{summary?.suspiciousUrls ?? 0}</span></div><div className="signal-row"><span className="signal-label"><i className="signal-dot" />Unique IPs</span><span className="signal-value">{summary?.uniqueIps ?? 0}</span></div><div className="signal-row"><span className="signal-label"><i className="signal-dot" />Countries</span><span className="signal-value">{summary?.countriesDetected ?? 0}</span></div></div></div></div>
    <div className="dashboard-grid"><div className="card card-pad"><div className="section-head"><span className="section-title">Classification distribution</span><span className="section-meta">model labels</span></div><div className="distribution">{(summary?.classificationDistribution ?? []).map((item, index) => <div className="dist-row" key={item.label}><span>{item.label}</span><span className="dist-track"><span className={cx('dist-fill', index === 1 && 'orange', index === 2 && 'red')} style={{ width: `${item.value}%` }} /></span><span className="dist-value">{item.value}%</span></div>)}</div></div><div className="card card-pad"><div className="section-head"><span className="section-title">Recent investigations</span><Link href="/investigations" className="section-meta" data-testid="link-dashboard-investigations">View all <ChevronRight size={12} style={{ verticalAlign: 'middle' }} /></Link></div>{investigationsQuery.isLoading ? <LoadingCard rows={3} /> : investigations?.length ? investigations.map(item => <div className="signal-row" key={item.id}><div><Link href={`/investigations/${item.id}`} className="row-link" data-testid={`link-investigation-${item.id}`}>{item.name}</Link><span className="subline">{item.emailCount} emails · {formatDate(item.createdAt)}</span></div><StatusChip value={item.status} /></div>) : <EmptyState icon={ClipboardList} title="No investigations" copy="Your next analysis will create one." />}</div></div>
  </main>;
}

function Investigations() {
  const [q, setQ] = useState('');
  const [risk, setRisk] = useState<'all' | 'dangerous' | 'low'>('all');
  const [newName, setNewName] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const params = useMemo(() => ({ q: q || undefined, risk: risk === 'all' ? undefined : risk, limit: 100 }), [q, risk]);
  const query = useListInvestigations(params);
  const create = useCreateInvestigation();
  const remove = useDeleteInvestigation();
  const client = useQueryClient();
  const items = query.data as Investigation[] | undefined;
  const submit = (event: FormEvent) => { event.preventDefault(); if (!newName.trim()) return; create.mutate({ data: { name: newName.trim() } }, { onSuccess: () => { setNewName(''); setShowCreate(false); client.invalidateQueries({ queryKey: getListInvestigationsQueryKey() }); } }); };
  return <main className="main"><div className="page-head"><div><div className="eyebrow">Case management</div><h1 className="page-title">Investigations</h1><p className="page-note">Each case is a bounded evidence set. Open one to move from a queue-level signal to the actual messages.</p></div><button className="btn btn-primary" onClick={() => setShowCreate(!showCreate)} data-testid="button-create-investigation"><Plus size={14} /> New investigation</button></div>
    {showCreate ? <form className="card card-pad" onSubmit={submit} style={{ display: 'flex', gap: 9, marginBottom: 15 }}><input className="search-box" style={{ flex: 1 }} placeholder="Investigation name" value={newName} onChange={e => setNewName(e.target.value)} data-testid="input-investigation-name" autoFocus /><button className="btn btn-primary" type="submit" disabled={create.isPending} data-testid="button-save-investigation">{create.isPending ? 'Creating…' : 'Create'}</button><button className="icon-btn" type="button" onClick={() => setShowCreate(false)} data-testid="button-cancel-investigation"><X size={15} /></button></form> : null}
    <div className="toolbar"><div className="toolbar-left"><label className="search-box"><Search size={14} /><input type="search" placeholder="Search investigations" value={q} onChange={e => setQ(e.target.value)} data-testid="input-search-investigations" /></label><select className="select" value={risk} onChange={e => setRisk(e.target.value as 'all' | 'dangerous' | 'low')} data-testid="select-investigation-risk"><option value="all">All risk zones</option><option value="dangerous">Dangerous</option><option value="low">Low risk</option></select></div><span className="section-meta">{items?.length ?? 0} records</span></div>
    <div className="card table-wrap">{query.isLoading ? <LoadingCard rows={5} /> : query.isError ? <ErrorState onRetry={() => query.refetch()} /> : items?.length ? <table className="data-table"><thead><tr><th>Investigation</th><th>Status</th><th>Mail / threads</th><th>Dangerous</th><th>Confidence</th><th /></tr></thead><tbody>{items.map(item => <tr key={item.id}><td><Link href={`/investigations/${item.id}`} className="row-link" data-testid={`link-investigation-row-${item.id}`}>{item.name}</Link><span className="subline">{item.id} · {formatDate(item.createdAt)}</span></td><td><StatusChip value={item.status} /></td><td>{item.emailCount} <span className="subline" style={{ display: 'inline', marginLeft: 4 }}>{item.threadCount} threads</span></td><td className={item.dangerousCount ? 'mono' : ''}>{item.dangerousCount}</td><td><ConfidenceCell confidence={item.confidence} /></td><td><button className="icon-btn" title="Delete investigation" onClick={() => { if (window.confirm('Delete this investigation?')) remove.mutate({ investigationId: item.id }, { onSuccess: () => client.invalidateQueries({ queryKey: getListInvestigationsQueryKey() }) }); }} data-testid={`button-delete-investigation-${item.id}`}><Trash2 size={14} /></button></td></tr>)}</tbody></table> : <EmptyState icon={ClipboardList} title="No investigations match" copy="Create a case or loosen the current filters." action={<button className="btn btn-ghost" onClick={() => { setQ(''); setRisk('all'); }} data-testid="button-clear-investigation-filters"><RefreshCw size={13} /> Clear filters</button>} />}</div>
  </main>;
}

function InvestigationDetailPage() {
  const { id } = useParams<{ id: string }>();
  const query = useGetInvestigation(id || '', { query: { enabled: Boolean(id), queryKey: getGetInvestigationQueryKey(id || '') } });
  const detail = query.data as InvestigationDetail | undefined;
  if (query.isLoading) return <main className="main"><LoadingCard rows={7} /></main>;
  if (query.isError || !detail) return <main className="main"><ErrorState onRetry={() => query.refetch()} /></main>;
   return <main className="main"><Link href="/investigations" className="crumb" style={{ marginBottom: 18, display: 'inline-flex' }} data-testid="link-back-investigations"><ArrowLeft size={14} /> Back to investigations</Link><div className="page-head"><div><div className="eyebrow">Investigation / {detail.id}</div><h1 className="page-title">{detail.name}</h1><p className="page-note">{detail.emailCount} emails · {detail.threadCount} reconstructed threads · created {formatDate(detail.createdAt)}</p></div><StatusChip value={detail.status} /></div><div className="metrics-grid"><div className="card metric"><div className="metric-label">Messages</div><div className="metric-value">{detail.emailCount}</div></div><div className="card metric"><div className="metric-label">Threads</div><div className="metric-value">{detail.threadCount}</div></div><div className="card metric"><div className="metric-label">Dangerous</div><div className="metric-value">{detail.dangerousCount}</div></div><div className="card metric"><div className="metric-label">Case confidence</div><div className="metric-value">{pct(detail.confidence)}</div></div></div><div className="detail-grid" style={{ marginTop: 14 }}><div className="card card-pad"><div className="section-head"><span className="section-title">Detected threads</span><span className="section-meta">{detail.threads.length} groups</span></div>{detail.threads.length ? <table className="data-table"><thead><tr><th>Subject</th><th>Decision</th><th>Risk</th><th>Score</th></tr></thead><tbody>{detail.threads.map(thread => <tr key={thread.id}><td><Link href={`/threads/${thread.id}`} className="row-link" data-testid={`link-detail-thread-${thread.id}`}>{thread.subject}</Link><span className="subline">{thread.messageCount} messages · {thread.participantCount} participants</span></td><td><StatusChip value={thread.decision} /></td><td><StatusChip value={thread.riskZone} /></td><td><span className="mono">{thread.riskScore}</span><span className="subline">risk score</span></td></tr>)}</tbody></table> : <EmptyState icon={Network} title="No threads detected" copy="The model has not grouped messages in this case." />}</div><div className="card card-pad"><div className="section-head"><span className="section-title">Case evidence</span><span className="section-meta">itemized</span></div><EvidenceList evidence={detail.evidence} /></div></div><StoredEmailsCard emails={detail.emails} /><TestGeolocationCard emails={detail.emails} /></main>;
}

function Threads() {
  const [q, setQ] = useState('');
  const [risk, setRisk] = useState<'all' | 'dangerous' | 'low'>('all');
  const params = useMemo(() => ({ q: q || undefined, risk: risk === 'all' ? undefined : risk, limit: 100 }), [q, risk]);
  const query = useListThreads(params);
  const threads = query.data as Thread[] | undefined;
  return <main className="main"><div className="page-head"><div><div className="eyebrow">Conversation graph</div><h1 className="page-title">Detected threads</h1><p className="page-note">Chronological groups inferred from sender, subject, timing, and relationship evidence.</p></div><Link href="/analyze" className="btn btn-primary" data-testid="link-threads-analyze"><Upload size={14} /> Analyze mail</Link></div><div className="toolbar"><div className="toolbar-left"><label className="search-box"><Search size={14} /><input type="search" placeholder="Search subjects or identifiers" value={q} onChange={e => setQ(e.target.value)} data-testid="input-search-threads" /></label><select className="select" value={risk} onChange={e => setRisk(e.target.value as 'all' | 'dangerous' | 'low')} data-testid="select-thread-risk"><option value="all">All zones</option><option value="dangerous">Dangerous</option><option value="low">Low risk</option></select></div><span className="section-meta">{threads?.length ?? 0} threads</span></div><div className="card table-wrap">{query.isLoading ? <LoadingCard rows={5} /> : query.isError ? <ErrorState onRetry={() => query.refetch()} /> : threads?.length ? <table className="data-table"><thead><tr><th>Thread</th><th>Decision</th><th>Risk zone</th><th>Risk score</th><th>Confidence</th><th>Last message</th></tr></thead><tbody>{threads.map(thread => <tr key={thread.id}><td><Link href={`/threads/${thread.id}`} className="row-link" data-testid={`link-thread-row-${thread.id}`}>{thread.subject}</Link><span className="subline">{thread.identifier} · {thread.participantCount} participants · {thread.messageCount} messages</span></td><td><StatusChip value={thread.decision} /></td><td><StatusChip value={thread.riskZone} /></td><td><span className="mono">{thread.riskScore}/100</span></td><td><ConfidenceCell confidence={thread.confidence} /></td><td className="mono" style={{ color: 'hsl(var(--muted-foreground))' }}>{formatDate(thread.lastMessage)}</td></tr>)}</tbody></table> : <EmptyState icon={Network} title="No detected threads" copy="Try another query or send a mailbox export to Analyze." />}</div></main>;
}

function ThreadDetailPage() {
  const { id } = useParams<{ id: string }>();
  const query = useGetThread(id || '', { query: { enabled: Boolean(id), queryKey: getGetThreadQueryKey(id || '') } });
  const detail = query.data as ThreadDetail | undefined;
  if (query.isLoading) return <main className="main"><LoadingCard rows={8} /></main>;
  if (query.isError || !detail) return <main className="main"><ErrorState onRetry={() => query.refetch()} /></main>;
   return <main className="main"><Link href="/threads" className="crumb" style={{ marginBottom: 18, display: 'inline-flex' }} data-testid="link-back-threads"><ArrowLeft size={14} /> Back to threads</Link><div className="card card-pad"><div className="thread-hero"><div><div className="eyebrow">Thread / {detail.identifier}</div><h1 className="thread-title">{detail.subject}</h1><div className="thread-meta"><span>{detail.participantCount} participants</span><span>{detail.messageCount} messages</span><span>first seen {formatDate(detail.firstMessage)}</span><StatusChip value={detail.decision} /></div></div><div className="score-box"><span className="score-number">{detail.riskScore}</span><span className="score-caption">risk score</span></div></div><div className="detail-grid"><div><div className="section-head"><span className="section-title">Chronological reconstruction</span><span className="section-meta">ordered by timestamp</span></div><div className="timeline">{detail.messages.map((message, index) => <div className="message" key={message.id}><div className="timeline-rail"><span className="timeline-dot" /></div><div className="message-card"><div className="message-head"><div><div className="message-sender">{message.sender}</div><div className="message-subject">{message.subject}</div></div><span className="message-time">{formatDate(message.timestamp)}</span></div><div style={{ marginTop: 12, display: 'flex', gap: 7, flexWrap: 'wrap' }}><StatusChip value={message.riskZone} /><StatusChip value={message.threadDecision} /><ConfidenceCell confidence={message.confidence} /></div></div></div>)}</div></div><aside><div className="section-head"><span className="section-title">Relationship evidence</span><span className="section-meta">{detail.relationshipEvidence.length} signals</span></div><EvidenceList evidence={detail.relationshipEvidence} /><div className="confidence-panel"><div className="section-head" style={{ marginBottom: 0 }}><span className="section-title">Model confidence</span><span className="section-meta">thread grouping</span></div><div className="interval-line"><span className="interval-dot" /></div><div className="interval-labels"><span>lower bound</span><span>estimate {pct(detail.confidence)}</span><span>upper bound</span></div><p className="section-meta" style={{ margin: '12px 0 0' }}>Decision is distinct from risk. Uncertain relationships are not treated as dangerous.</p></div><TestGeolocationCard emails={detail.messages} /></aside></div></div></main>;
}

function Analyze() {
  const [name, setName] = useState('');
  const [raw, setRaw] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const [jobId, setJobId] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [, setLocation] = useLocation();
  const analyze = useAnalyzeEmails();
  const requestUploadUrl = useRequestUploadUrl();
  const jobQuery = useGetAnalysisJob(jobId, { query: { enabled: Boolean(jobId), queryKey: getGetAnalysisJobQueryKey(jobId || 'pending'), refetchInterval: 1600 } });
  const job = jobQuery.data as AnalysisJob | undefined;
  const fileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const selected = Array.from(event.target.files ?? []);
    if (!selected.length) return;
    setFiles(selected);
    setRaw('');
    if (!name.trim()) setName(selected[0].name.replace(/\.[^.]+$/, ''));
    setUploadError('');
  };
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!name.trim() || (!raw.trim() && !files.length)) return;
    setUploadError('');
    setUploading(Boolean(files.length));
    try {
      const emails = files.length
        ? await Promise.all(files.map(async (file) => {
            const upload = await requestUploadUrl.mutateAsync({
              data: { name: file.name, size: file.size, contentType: file.type || 'message/rfc822' },
            });
            const stored = await fetch(upload.uploadURL, {
              method: 'PUT',
              headers: { 'Content-Type': file.type || 'message/rfc822' },
              body: file,
            });
            if (!stored.ok) throw new Error(`Unable to store ${file.name}`);
            return {
              raw: await file.text(),
              filename: file.name,
              objectPath: upload.objectPath,
              size: file.size,
              contentType: file.type || 'message/rfc822',
            };
          }))
        : [{ raw: raw.trim() }];
      setUploading(false);
      analyze.mutate(
        { data: { name: name.trim(), emails } },
        { onSuccess: response => { setJobId(response.id); setLocation(`/reports/${response.investigationId}`); } },
      );
    } catch (error) {
      setUploading(false);
      setUploadError(error instanceof Error ? error.message : 'Unable to store the uploaded email.');
    }
  };
  const progress = job ? Math.round((job.processed / Math.max(job.total, 1)) * 100) : 0;
  const isBusy = uploading || analyze.isPending;
  return <main className="main"><div className="page-head"><div><div className="eyebrow">Ingest / explain</div><h1 className="page-title">Analyze email</h1><p className="page-note">Upload one or more raw messages. MailTrace stores the originals privately, extracts forensic indicators, and opens a report for the signed-in analyst.</p></div><span className="status safe"><ShieldCheck size={11} /> explainability on</span></div><div className="analysis-layout"><form className="card card-pad" onSubmit={submit}><div className="section-head"><span className="section-title">Input source</span><span className="section-meta">.eml / .txt / .mbox / pasted</span></div><div className="form-field"><label htmlFor="analysis-name">Investigation name</label><input id="analysis-name" value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Vendor invoice cluster" required data-testid="input-analysis-name" /></div><div className="dropzone"><div className="drop-icon"><Upload size={20} /></div><h3>Upload mailbox messages</h3><p>Choose one or more EML, TXT, or MBOX files. Originals are stored privately before the forensic report is generated.</p><label className="btn btn-ghost" htmlFor="analysis-file" data-testid="label-upload-file"><Upload size={14} /> Choose files</label><input className="file-input" id="analysis-file" type="file" multiple accept=".eml,.txt,.mbox" onChange={fileChange} data-testid="input-analysis-file" />{files.length ? <div className="section-meta" style={{ marginTop: 10 }}>{files.map(file => file.name).join(' · ')}</div> : null}</div><div style={{ marginTop: 16 }}><div className="section-head"><label className="section-title" htmlFor="analysis-raw">Or paste raw message content</label><span className="section-meta">{raw.length} chars</span></div><textarea className="paste-input" id="analysis-raw" value={raw} onChange={e => { setRaw(e.target.value); setFiles([]); }} placeholder={'From: sender@example.com\\nTo: analyst@company.com\\nSubject: Please review\\n\\nPaste message body…'} required={!files.length} data-testid="textarea-analysis-raw" /></div><button className="btn btn-primary" type="submit" style={{ width: '100%', marginTop: 14 }} disabled={isBusy} data-testid="button-start-analysis"><Send size={14} /> {uploading ? 'Storing source…' : analyze.isPending ? 'Building report…' : 'Store and analyze'}</button>{uploadError ? <p style={{ color: 'hsl(var(--destructive))', fontSize: 11, margin: '10px 0 0' }}>{uploadError}</p> : null}{analyze.isError ? <p style={{ color: 'hsl(var(--destructive))', fontSize: 11, margin: '10px 0 0' }}>Report generation failed. Check the input and retry.</p> : null}</form><div className="grid"><div className="card card-pad"><div className="section-head"><span className="section-title">Forensic pipeline</span><span className="section-meta">source to report</span></div><div className="step-list"><div className="step"><span className="step-num">01</span><div className="step-copy"><strong>Store the original</strong><span>Each uploaded source is written to private object storage and linked to your analyst account.</span></div></div><div className="step"><span className="step-num">02</span><div className="step-copy"><strong>Extract indicators</strong><span>Headers, sender domains, URLs, IPs, reply chains, and risk language are parsed without rewriting the source.</span></div></div><div className="step"><span className="step-num">03</span><div className="step-copy"><strong>Show the receipts</strong><span>The report keeps every finding tied to evidence, risk score, and a bounded confidence interval.</span></div></div></div></div><div className="card card-pad">{job ? <><div className="section-head"><span className="section-title">Analysis job</span><StatusChip value={job.status} /></div><div className="mono" style={{ fontSize: 11, color: 'hsl(var(--muted-foreground))' }}>JOB {job.id}</div><div className="job-progress"><div style={{ width: `${progress}%` }} /></div><div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11 }}><span>{job.processed} / {job.total} processed</span><span className="mono">{progress}%</span></div>{job.message ? <p className="page-note">{job.message}</p> : null}{job.investigationId ? <Link href={`/reports/${job.investigationId}`} className="btn btn-ghost" style={{ marginTop: 15 }} data-testid="link-analysis-report">Open forensic report <ChevronRight size={13} /></Link> : null}</> : <EmptyState icon={FileText} title="No report yet" copy="Store and analyze a message to open its forensic report." />}</div></div></div></main>;
}

function ForensicReportPage() {
  const { reportId } = useParams<{ reportId: string }>();
  const query = useGetForensicReport(reportId || '', { query: { enabled: Boolean(reportId), queryKey: getGetForensicReportQueryKey(reportId || '') } });
  const report = query.data as ForensicReport | undefined;
  if (query.isLoading) return <main className="main"><LoadingCard rows={8} /></main>;
  if (query.isError || !report) return <main className="main"><ErrorState onRetry={() => query.refetch()} /></main>;
  return <main className="main"><Link href="/analyze" className="crumb" style={{ marginBottom: 18, display: 'inline-flex' }} data-testid="link-back-analysis"><ArrowLeft size={14} /> Back to analysis</Link><div className="page-head"><div><div className="eyebrow">Forensic report / {report.id}</div><h1 className="page-title">{report.name}</h1><p className="page-note">Generated {formatDate(report.createdAt)} from {report.emailCount} stored message{report.emailCount === 1 ? '' : 's'}. Every call below is tied to extracted evidence rather than an absolute verdict.</p></div><StatusChip value={report.riskZone} /></div><div className="metrics-grid"><div className="card metric"><div className="metric-label">Messages reviewed</div><div className="metric-value">{report.emailCount}</div><div className="metric-detail"><Mail size={12} /> stored source set</div></div><div className="card metric"><div className="metric-label">Thread groups</div><div className="metric-value">{report.threadCount}</div><div className="metric-detail good"><Network size={12} /> reconstructed</div></div><div className="card metric"><div className="metric-label">Average risk</div><div className="metric-value">{report.riskScore}/100</div><div className={cx('metric-detail', report.riskZone === 'dangerous' ? 'warn' : '')}><ShieldAlert size={12} /> bounded score</div></div><div className="card metric"><div className="metric-label">Report status</div><div className="metric-value" style={{ fontSize: 20 }}>READY</div><div className="metric-detail good"><ShieldCheck size={12} /> evidence attached</div></div></div><div className="card card-pad" style={{ marginTop: 14 }}><div className="section-head"><span className="section-title">Executive read</span><span className="section-meta">risk zone: {report.riskZone}</span></div><p className="page-note" style={{ maxWidth: 900, marginTop: 0 }}>{report.summary}</p><div className="feature-grid" style={{ marginTop: 18 }}>{report.findings.map((finding, index) => <div className="feature" key={`${finding.title}-${index}`}><div className={cx('status', finding.severity === 'danger' ? 'dangerous' : finding.severity === 'warning' ? 'uncertain' : 'safe')} style={{ marginBottom: 12 }}>{finding.severity}</div><h3>{finding.title}</h3><p>{finding.detail}</p></div>)}</div></div><div className="card card-pad" style={{ marginTop: 14 }}><div className="section-head"><span className="section-title">Message-level findings</span><span className="section-meta">{report.emails.length} source records</span></div><div className="table-wrap"><table className="data-table"><thead><tr><th>Source</th><th>Sender / subject</th><th>Classification</th><th>Risk</th><th>Confidence</th><th>Indicators</th></tr></thead><tbody>{report.emails.map(email => <tr key={email.id}><td><div style={{ display: 'flex', alignItems: 'center', gap: 8 }}><FileText size={15} color="hsl(var(--primary))" /><div><strong>{email.filename}</strong><span className="subline">{formatDate(email.timestamp)}</span></div></div></td><td><strong>{email.sender}</strong><span className="subline">{email.subject}</span></td><td><span className="status processing">{email.classification}</span></td><td><StatusChip value={email.riskZone} /><span className="subline">{email.riskScore}/100</span></td><td><ConfidenceCell confidence={email.confidence} /></td><td><span className="mono">{email.evidence.length} signals</span><span className="subline">{email.urls.length} URLs · {email.ips.length} IPs</span></td></tr>)}</tbody></table></div></div><div className="detail-grid" style={{ marginTop: 14 }}>{report.emails.map(email => <div className="card card-pad" key={`${email.id}-evidence`}><div className="section-head"><span className="section-title">{email.filename}</span><span className="section-meta">evidence</span></div><EvidenceList evidence={email.evidence} /><div className="confidence-panel"><div className="section-head" style={{ marginBottom: 0 }}><span className="section-title">Confidence interval</span><ConfidenceCell confidence={email.confidence} /></div><p className="section-meta" style={{ margin: '10px 0 0' }}>Model {email.confidence.modelVersion}. This interval describes detection confidence, not identity certainty.</p></div></div>)}</div></main>;
}

function SearchPage() {
  const [input, setInput] = useState('');
  const [q, setQ] = useState('');
  const query = useSearchIntelligence({ q: q || 'pending', limit: 50 }, { query: { enabled: Boolean(q), queryKey: getSearchIntelligenceQueryKey({ q: q || 'pending', limit: 50 }) } });
  const results = query.data as SearchResult[] | undefined;
  const submit = (event: FormEvent) => { event.preventDefault(); setQ(input.trim()); };
  const resultIcon = (kind: string) => kind === 'email' ? Mail : kind === 'thread' ? Network : kind === 'url' ? Link2 : kind === 'ip' ? Globe2 : kind === 'sender' ? UserRound : ClipboardList;
  return <main className="main"><div className="page-head"><div><div className="eyebrow">Global intelligence</div><h1 className="page-title">Search the index.</h1><p className="page-note">Query subjects, senders, domains, IPs, URLs, and investigations from one place.</p></div></div><form className="search-box" style={{ width: '100%', maxWidth: 660, height: 44, marginBottom: 18 }} onSubmit={submit}><Search size={16} /><input value={input} onChange={e => setInput(e.target.value)} placeholder="Try a sender, domain, IP, or subject…" data-testid="input-global-search" /><button className="btn btn-primary" type="submit" data-testid="button-global-search">Search</button></form><div className="card card-pad">{!q ? <EmptyState icon={FileSearch} title="Ready when you are" copy="Searches are scoped to indexed intelligence and return the source type and risk context." /> : query.isLoading ? <LoadingCard rows={5} /> : query.isError ? <ErrorState onRetry={() => query.refetch()} /> : results?.length ? results.map(result => { const Icon = resultIcon(result.kind); return <div className="search-result" key={`${result.kind}-${result.id}`} data-testid={`search-result-${result.id}`}><span className="result-kind"><Icon size={16} /></span><div className="result-copy"><div className="result-title">{result.title}</div><div className="result-subtitle">{result.subtitle}</div></div><div style={{ textAlign: 'right' }}><span className="status" style={{ marginBottom: 7 }}>{result.kind}</span><StatusChip value={result.riskZone} /><div style={{ marginTop: 7 }}><ConfidenceCell confidence={result.confidence} /></div></div></div>; }) : <EmptyState icon={FileSearch} title="No matching signals" copy="Try a broader term or search a full sender domain." />}</div></main>;
}

function Sessions() {
  const query = useListSessions();
  const sessions = query.data as LoginSession[] | undefined;
  return <main className="main"><div className="page-head"><div><div className="eyebrow">Account security</div><h1 className="page-title">Login sessions</h1><p className="page-note">Review the devices that have accessed this workspace. Confidence is a session signal, not an identity guarantee.</p></div><span className="status safe"><LockKeyhole size={11} /> session controls</span></div><div className="card table-wrap">{query.isLoading ? <LoadingCard rows={4} /> : query.isError ? <ErrorState onRetry={() => query.refetch()} /> : sessions?.length ? <table className="data-table"><thead><tr><th>Device</th><th>Browser</th><th>Location</th><th>Last seen</th><th>Confidence</th><th /></tr></thead><tbody>{sessions.map(session => <tr key={session.id}><td><div style={{ display: 'flex', gap: 9, alignItems: 'center' }}><Laptop2 size={15} color="hsl(var(--primary))" /><div><strong>{session.device}</strong>{session.current ? <span className="subline" style={{ color: 'hsl(155 50% 35%)' }}>current session</span> : null}</div></div></td><td>{session.browser}</td><td>{session.location}</td><td className="mono">{formatDate(session.lastSeen)}</td><td><ConfidenceCell confidence={session.confidence} /></td><td>{session.current ? <span className="section-meta">this device</span> : <button className="btn btn-danger" onClick={() => window.alert('Session revocation is ready for the Clerk session API.')} data-testid={`button-revoke-session-${session.id}`}>Revoke</button>}</td></tr>)}</tbody></table> : <EmptyState icon={Laptop2} title="No login sessions" copy="Session activity will appear after authentication." />}</div></main>;
}

function SettingsPage() {
  const [saved, setSaved] = useState(false);
  return <main className="main"><div className="page-head"><div><div className="eyebrow">Workspace controls</div><h1 className="page-title">Settings</h1><p className="page-note">Keep your profile and data handling preferences close at hand.</p></div></div><div className="detail-grid"><div className="grid"><div className="card card-pad"><div className="section-head"><span className="section-title">Analyst profile</span><span className="section-meta">workspace identity</span></div><div className="form-field"><label htmlFor="profile-name">Display name</label><input id="profile-name" defaultValue="M. Analyst" data-testid="input-profile-name" /></div><div className="form-field"><label htmlFor="profile-role">Role</label><input id="profile-role" defaultValue="Security operations" data-testid="input-profile-role" /></div><button className="btn btn-primary" onClick={() => setSaved(true)} data-testid="button-save-profile"><UserRound size={14} /> Save profile</button>{saved ? <span style={{ marginLeft: 10, color: 'hsl(155 50% 35%)', fontSize: 11 }} data-testid="status-profile-saved">Profile saved</span> : null}</div><div className="card card-pad"><div className="section-head"><span className="section-title">Privacy</span><span className="section-meta">default handling</span></div><div className="signal-row"><div><strong style={{ fontSize: 12 }}>Retain raw message content</strong><span className="subline">Keep source content available for evidence drill-down.</span></div><input type="checkbox" defaultChecked data-testid="checkbox-retain-content" /></div><div className="signal-row"><div><strong style={{ fontSize: 12 }}>Include model telemetry</strong><span className="subline">Share anonymized performance signals to improve detection.</span></div><input type="checkbox" defaultChecked data-testid="checkbox-telemetry" /></div></div></div><div className="grid"><div className="card card-pad"><div className="section-head"><span className="section-title">Data controls</span><span className="section-meta">irreversible actions</span></div><button className="btn btn-ghost" style={{ width: '100%', justifyContent: 'flex-start', marginBottom: 9 }} onClick={() => window.alert('Export request queued.')} data-testid="button-export-data"><Database size={14} /> Export workspace data</button><button className="btn btn-danger" style={{ width: '100%', justifyContent: 'flex-start' }} onClick={() => window.alert('Contact an administrator to delete the workspace.')} data-testid="button-delete-data"><Trash2 size={14} /> Request data deletion</button></div><div className="card card-pad"><div className="section-head"><span className="section-title">Detection policy</span><span className="section-meta">read-only</span></div><div className="signal-row"><span className="signal-label"><SlidersHorizontal size={14} /> Model version</span><span className="mono">trace-2.4</span></div><div className="signal-row"><span className="signal-label"><ShieldAlert size={14} /> Uncertainty policy</span><span className="status uncertain">visible</span></div><div className="signal-row"><span className="signal-label"><Globe2 size={14} /> IP enrichment</span><span className="status safe">enabled</span></div></div></div></div></main>;
}

function NotFound() {
  return <div className="auth-page"><div className="auth-card" style={{ textAlign: 'center' }}><div className="empty-icon"><CircleHelp size={18} /></div><h1 className="auth-title">Signal not found</h1><p className="auth-copy">This route is outside the current workspace index.</p><Link href="/" className="btn btn-primary" data-testid="link-not-found-home">Return home</Link></div></div>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function Router() {
  return <RoutedErrorBoundary><Switch>
    <Route path="/" component={PublicHome} />
    <Route path="/sign-in/*?" component={ClerkSignInPage} />
    <Route path="/sign-up/*?" component={ClerkSignUpPage} />
    <Route path="/user-portal" component={() => <Protected><Dashboard /></Protected>} />
    <Route path="/investigations" component={() => <Protected><Investigations /></Protected>} />
    <Route path="/investigations/:id" component={() => <Protected><InvestigationDetailPage /></Protected>} />
    <Route path="/threads" component={() => <Protected><Threads /></Protected>} />
    <Route path="/threads/:id" component={() => <Protected><ThreadDetailPage /></Protected>} />
    <Route path="/analyze" component={() => <Protected><Analyze /></Protected>} />
    <Route path="/reports/:reportId" component={() => <Protected><ForensicReportPage /></Protected>} />
    <Route path="/search" component={() => <Protected><SearchPage /></Protected>} />
    <Route path="/sessions" component={() => <Protected><Sessions /></Protected>} />
    <Route path="/settings" component={() => <Protected><SettingsPage /></Protected>} />
    <Route component={NotFound} />
  </Switch></RoutedErrorBoundary>;
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const client = useQueryClient();
  const previousUserId = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (previousUserId.current !== undefined && previousUserId.current !== userId) {
        client.clear();
      }
      previousUserId.current = userId;
    });
    return unsubscribe;
  }, [addListener, client]);

  return null;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();
  return <ClerkProvider
    publishableKey={clerkPubKey}
    proxyUrl={clerkProxyUrl}
    appearance={clerkAppearance}
    signInUrl={`${basePath}/sign-in`}
    signUpUrl={`${basePath}/sign-up`}
    localization={{
      signIn: { start: { title: 'Welcome back, analyst', subtitle: 'Sign in to continue reconstructing the signal.' } },
      signUp: { start: { title: 'Create your analyst account', subtitle: 'Set up a secure workspace for explainable email investigations.' } },
    }}
    routerPush={(to) => setLocation(stripBase(to))}
    routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
  >
    <QueryClientProvider client={queryClient}>
      <ClerkQueryClientCacheInvalidator />
      <TooltipProvider><Router /><Toaster /></TooltipProvider>
    </QueryClientProvider>
  </ClerkProvider>;
}

function App() {
  return <WouterRouter base={basePath}><ClerkProviderWithRoutes /></WouterRouter>;
}

export default App;
import type {
  EmailRecord,
  ForensicEmail,
  ForensicReport,
  Investigation,
  InvestigationDetail,
  Thread,
  ThreadDetail,
} from "@workspace/api-zod";

function asDate(value: Date | string) {
  return value instanceof Date ? value : new Date(value);
}

function subjectKey(subject: string) {
  return subject.replace(/^\s*((re|fw|fwd)\s*:\s*)+/i, "").replace(/\s+/g, " ").trim().toLowerCase();
}

function domainOf(sender: string) {
  return sender.split("@")[1]?.toLowerCase();
}

export function reportEmails(report: ForensicReport): EmailRecord[] {
  return report.emails.map((email) => ({
    id: email.id,
    sender: email.sender,
    recipients: email.recipients,
    subject: email.subject,
    timestamp: asDate(email.timestamp),
    classification: email.classification,
    classificationConfidence: email.confidence.score,
    riskZone: email.riskZone,
    riskScore: email.riskScore,
    threadDecision: "uncertain",
    confidence: email.confidence,
    evidence: email.evidence,
    ips: email.ips,
    urls: email.urls,
    domain: domainOf(email.sender),
  }));
}

function threadMessages(report: ForensicReport, emails: ForensicEmail[]) {
  const allEmails = reportEmails(report);
  return emails.map((email) => allEmails.find((item) => item.id === email.id)!);
}

export function reportThreads(report: ForensicReport): ThreadDetail[] {
  const groups = new Map<string, ForensicEmail[]>();
  for (const email of report.emails) {
    const key = subjectKey(email.subject) || email.id;
    groups.set(key, [...(groups.get(key) ?? []), email]);
  }

  return Array.from(groups.entries()).map(([key, emails], index) => {
    const messages = threadMessages(report, emails);
    const firstMessage = messages.reduce((first, message) => message.timestamp < first ? message.timestamp : first, messages[0].timestamp);
    const lastMessage = messages.reduce((last, message) => message.timestamp > last ? message.timestamp : last, messages[0].timestamp);
    const dangerous = messages.some((message) => message.riskZone === "dangerous");
    const uncertain = messages.some((message) => message.riskZone === "uncertain");
    const decision = messages.length > 1 ? "same_thread" : "uncertain";
    const riskZone = dangerous ? "dangerous" : uncertain ? "uncertain" : "low";

    return {
      id: `${report.id}-thread-${index + 1}`,
      identifier: `${report.id.toUpperCase()}-${String(index + 1).padStart(2, "0")}`,
      subject: messages[0].subject,
      participantCount: new Set(messages.flatMap((message) => [message.sender, ...(message.recipients ?? [])])).size,
      messageCount: messages.length,
      confidence: messages.reduce((sum, message) => sum + message.confidence.score, 0) / messages.length,
      decision,
      riskZone,
      riskScore: Math.round(messages.reduce((sum, message) => sum + message.riskScore, 0) / messages.length),
      status: dangerous || uncertain ? "needs_review" : "normal",
      firstMessage,
      lastMessage,
      messages,
      relationshipEvidence: emails.flatMap((email) => email.evidence).slice(0, 6),
    };
  });
}

export function reportAsInvestigation(report: ForensicReport): InvestigationDetail {
  const threads = reportThreads(report);
  return {
    id: report.id,
    name: report.name,
    createdAt: asDate(report.createdAt),
    status: report.status === "complete" ? (report.riskZone === "low" ? "complete" : "needs_review") : "processing",
    emailCount: report.emailCount,
    threadCount: report.threadCount,
    dangerousCount: report.emails.filter((email) => email.riskZone === "dangerous").length,
    confidence: report.emails.length
      ? report.emails.reduce((sum, email) => sum + email.confidence.score, 0) / report.emails.length
      : 0,
    threads,
    emails: reportEmails(report),
    evidence: report.findings.map((finding) => ({
      label: finding.title,
      detail: finding.detail,
      weight: finding.severity === "danger" ? 0.9 : finding.severity === "warning" ? 0.7 : 0.5,
      signal: finding.severity === "danger" ? "negative" : finding.severity === "warning" ? "neutral" : "positive",
    })),
  };
}

export function reportAsInvestigationRow(report: ForensicReport): Investigation {
  const detail = reportAsInvestigation(report);
  return {
    id: detail.id,
    name: detail.name,
    createdAt: detail.createdAt,
    status: detail.status,
    emailCount: detail.emailCount,
    threadCount: detail.threadCount,
    dangerousCount: detail.dangerousCount,
    confidence: detail.confidence,
  };
}

export function reportAsThreadDetails(report: ForensicReport): ThreadDetail[] {
  return reportThreads(report);
}
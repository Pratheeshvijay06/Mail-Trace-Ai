import type {
  DashboardSummary,
  EmailRecord,
  Evidence,
  Investigation,
  InvestigationDetail,
  LoginSession,
  SearchResult,
  Thread,
  ThreadDetail,
} from "@workspace/api-zod";

const evidence = (items: Array<[string, string, number, "positive" | "negative" | "neutral"]>): Evidence[] =>
  items.map(([label, detail, weight, signal]) => ({ label, detail, weight, signal }));

const sharedEvidence = evidence([
  ["In-Reply-To matched", "Message-ID matches the parent message in the reference chain.", 0.98, "positive"],
  ["Same participants", "Sender and recipient set remains consistent across the pair.", 0.84, "positive"],
  ["Subject similarity", "Normalized subject similarity is 94%.", 0.62, "positive"],
  ["Temporal plausibility", "The reply arrived 18 minutes after the referenced message.", 0.31, "positive"],
]);

export const demoEmails: EmailRecord[] = [
  {
    id: "email-001",
    sender: "maya.chen@northstar.example",
    recipients: ["alex.rivera@northstar.example"],
    subject: "Q3 access review — follow-up",
    timestamp: new Date("2026-09-08T08:42:00.000Z"),
    classification: "Professional",
    classificationConfidence: 0.942,
    riskZone: "low",
    riskScore: 12,
    threadDecision: "same_thread",
    confidence: { score: 0.96, lowerBound: 0.92, upperBound: 0.98, modelVersion: "thread-v1.4.2" },
    evidence: sharedEvidence,
    ips: ["203.0.113.42"],
    urls: [],
    domain: "northstar.example",
  },
  {
    id: "email-002",
    sender: "alex.rivera@northstar.example",
    recipients: ["maya.chen@northstar.example"],
    subject: "Re: Q3 access review — follow-up",
    timestamp: new Date("2026-09-08T09:00:00.000Z"),
    classification: "Conversation/Thread",
    classificationConfidence: 0.971,
    riskZone: "low",
    riskScore: 8,
    threadDecision: "same_thread",
    confidence: { score: 0.98, lowerBound: 0.94, upperBound: 0.99, modelVersion: "thread-v1.4.2" },
    evidence: sharedEvidence,
    ips: ["203.0.113.43"],
    urls: [],
    domain: "northstar.example",
  },
  {
    id: "email-003",
    sender: "billing@northstar-payments.example",
    recipients: ["maya.chen@northstar.example"],
    subject: "Invoice 84319 ready for review",
    timestamp: new Date("2026-09-07T14:20:00.000Z"),
    classification: "Financial",
    classificationConfidence: 0.884,
    riskZone: "dangerous",
    riskScore: 82,
    threadDecision: "uncertain",
    confidence: { score: 0.71, lowerBound: 0.58, upperBound: 0.82, modelVersion: "thread-v1.4.2" },
    evidence: evidence([
      ["Reply-To mismatch", "Reply-To points to a different domain than the sender.", 0.89, "negative"],
      ["Suspicious URL pattern", "Link uses a short-lived redirector and a new domain.", 0.87, "negative"],
      ["Display name anomaly", "The display name resembles a known vendor but the domain is unverified.", 0.74, "negative"],
    ]),
    ips: ["198.51.100.19"],
    urls: ["https://invoice-review.example/84319"],
    domain: "northstar-payments.example",
  },
];

export const demoThreads: Thread[] = [
  {
    id: "thread-001",
    identifier: "THREAD-2026-0048",
    subject: "Q3 access review — follow-up",
    participantCount: 2,
    messageCount: 2,
    confidence: 0.98,
    decision: "same_thread",
    riskZone: "low",
    riskScore: 10,
    status: "normal",
    firstMessage: new Date("2026-09-08T08:42:00.000Z"),
    lastMessage: new Date("2026-09-08T09:00:00.000Z"),
  },
  {
    id: "thread-002",
    identifier: "THREAD-2026-0047",
    subject: "Invoice 84319 ready for review",
    participantCount: 1,
    messageCount: 1,
    confidence: 0.71,
    decision: "uncertain",
    riskZone: "dangerous",
    riskScore: 82,
    status: "needs_review",
    firstMessage: new Date("2026-09-07T14:20:00.000Z"),
    lastMessage: new Date("2026-09-07T14:20:00.000Z"),
  },
];

export const demoInvestigations: Investigation[] = [
  {
    id: "inv-001",
    name: "September vendor review",
    createdAt: new Date("2026-09-08T09:02:00.000Z"),
    status: "needs_review",
    emailCount: 3,
    threadCount: 2,
    dangerousCount: 1,
    confidence: 0.91,
  },
  {
    id: "inv-002",
    name: "Q3 identity access audit",
    createdAt: new Date("2026-09-05T11:48:00.000Z"),
    status: "complete",
    emailCount: 48,
    threadCount: 16,
    dangerousCount: 3,
    confidence: 0.94,
  },
  {
    id: "inv-003",
    name: "Recruitment mailbox triage",
    createdAt: new Date("2026-08-28T16:31:00.000Z"),
    status: "complete",
    emailCount: 124,
    threadCount: 38,
    dangerousCount: 0,
    confidence: 0.97,
  },
];

export const demoSummary: DashboardSummary = {
  emailsAnalyzed: 175,
  threadsDetected: 56,
  dangerousCount: 4,
  lowRiskCount: 161,
  uncertainCount: 10,
  suspiciousUrls: 7,
  uniqueIps: 29,
  countriesDetected: 8,
  trend: [
    { label: "Aug 26", emails: 18, threads: 7 },
    { label: "Aug 28", emails: 26, threads: 9 },
    { label: "Aug 30", emails: 12, threads: 6 },
    { label: "Sep 01", emails: 34, threads: 12 },
    { label: "Sep 03", emails: 21, threads: 8 },
    { label: "Sep 05", emails: 38, threads: 10 },
    { label: "Sep 08", emails: 26, threads: 4 },
  ],
  classificationDistribution: [
    { label: "Professional", value: 71 },
    { label: "Conversation", value: 48 },
    { label: "Transactional", value: 24 },
    { label: "Recruitment", value: 18 },
    { label: "Other", value: 14 },
  ],
  riskDistribution: [
    { label: "Low risk", value: 161 },
    { label: "Dangerous", value: 4 },
    { label: "Uncertain", value: 10 },
  ],
};

export function getInvestigation(id: string): InvestigationDetail | undefined {
  const investigation = demoInvestigations.find((item) => item.id === id);
  if (!investigation) return undefined;
  return {
    ...investigation,
    threads: demoThreads,
    emails: demoEmails,
    evidence: evidence([
      ["Header evidence", "Message-ID and In-Reply-To relationships were parsed before semantic scoring.", 0.98, "positive"],
      ["Semantic evidence", "Body embedding similarity was used only after candidate retrieval.", 0.76, "positive"],
      ["Manual review required", "One vendor message has a domain and Reply-To mismatch.", 0.89, "negative"],
    ]),
  };
}

export function getThread(id: string): ThreadDetail | undefined {
  const thread = demoThreads.find((item) => item.id === id);
  if (!thread) return undefined;
  return {
    ...thread,
    messages: thread.id === "thread-001" ? demoEmails.slice(0, 2) : demoEmails.slice(2),
    relationshipEvidence: thread.id === "thread-001" ? sharedEvidence : demoEmails[2].evidence,
  };
}

export const demoSessions: LoginSession[] = [
  {
    id: "session-current",
    device: "MacBook Pro",
    browser: "Chrome 140",
    location: "Bengaluru, India",
    confidence: 0.78,
    lastSeen: new Date("2026-09-08T09:10:00.000Z"),
    current: true,
  },
  {
    id: "session-previous",
    device: "iPhone 15",
    browser: "Safari Mobile",
    location: "Bengaluru, India",
    confidence: 0.74,
    lastSeen: new Date("2026-09-07T18:45:00.000Z"),
    current: false,
  },
];

export const demoSearchResults: SearchResult[] = [
  { id: "thread-001", kind: "thread", title: "Q3 access review — follow-up", subtitle: "THREAD-2026-0048 · 2 messages · northstar.example", riskZone: "low", confidence: 0.98 },
  { id: "email-003", kind: "email", title: "Invoice 84319 ready for review", subtitle: "billing@northstar-payments.example · suspicious URL", riskZone: "dangerous", confidence: 0.71 },
  { id: "inv-002", kind: "investigation", title: "Q3 identity access audit", subtitle: "48 emails · 16 threads · 3 dangerous", riskZone: "low", confidence: 0.94 },
];
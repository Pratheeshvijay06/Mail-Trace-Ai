import { randomUUID } from "node:crypto";
import type { EmailInput, Evidence, ForensicEmail, ForensicReport } from "@workspace/api-zod";

const URL_PATTERN = /https?:\/\/[^\s<>"')]+/gi;
const IP_PATTERN = /\b(?:\d{1,3}\.){3}\d{1,3}\b/g;
const EMAIL_PATTERN = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
const HEADER_NAMES = new Set(["from", "to", "cc", "bcc", "subject", "date", "message-id", "in-reply-to", "references", "reply-to"]);

function parseHeaders(raw: string) {
  const split = raw.split(/\r?\n\r?\n/, 1);
  const headerLines = (split[0] ?? "").split(/\r?\n/);
  const unfolded: string[] = [];
  for (const line of headerLines) {
    if (/^\s/.test(line) && unfolded.length) unfolded[unfolded.length - 1] += ` ${line.trim()}`;
    else unfolded.push(line);
  }
  const headers = new Map<string, string>();
  for (const line of unfolded) {
    const separator = line.indexOf(":");
    if (separator < 1) continue;
    const key = line.slice(0, separator).trim().toLowerCase();
    if (HEADER_NAMES.has(key)) headers.set(key, line.slice(separator + 1).trim());
  }
  return { headers, body: raw.slice((split[0] ?? "").length).replace(/^\r?\n\r?\n/, "") };
}

function addresses(value: string | undefined) {
  return value ? Array.from(new Set(value.match(EMAIL_PATTERN) ?? [])) : [];
}

function domainOf(value: string) {
  return value.split("@")[1]?.toLowerCase() ?? "";
}

function normalizedSubject(value: string) {
  return value.replace(/^\s*((re|fw|fwd)\s*:\s*)+/i, "").replace(/\s+/g, " ").trim().toLowerCase();
}

function clamp(value: number, min = 0, max = 1) {
  return Math.max(min, Math.min(max, value));
}

function evidenceItem(label: string, detail: string, weight: number, signal: Evidence["signal"]): Evidence {
  return { label, detail, weight: clamp(weight), signal };
}

function parseOne(input: EmailInput, index: number): ForensicEmail {
  const { headers, body } = parseHeaders(input.raw);
  const sender = addresses(headers.get("from"))[0] ?? headers.get("from") ?? "unknown sender";
  const recipients = Array.from(new Set([
    ...addresses(headers.get("to")),
    ...addresses(headers.get("cc")),
    ...addresses(headers.get("bcc")),
  ]));
  const subject = headers.get("subject") || "(no subject)";
  const timestamp = new Date(headers.get("date") || Date.now());
  const safeTimestamp = Number.isNaN(timestamp.getTime()) ? new Date() : timestamp;
  const urls = Array.from(new Set(input.raw.match(URL_PATTERN) ?? []));
  const ips = Array.from(new Set(input.raw.match(IP_PATTERN) ?? []));
  const senderDomain = domainOf(sender);
  const replyTo = headers.get("reply-to") || null;
  const replyDomain = replyTo ? domainOf(addresses(replyTo)[0] ?? replyTo) : "";
  const urlDomains = Array.from(new Set(urls.map((url) => {
    try { return new URL(url).hostname.toLowerCase(); } catch { return ""; }
  }).filter(Boolean)));
  const lower = `${subject}\n${body}`.toLowerCase();
  const evidence: Evidence[] = [];
  let riskScore = 0;

  if (headers.get("message-id")) evidence.push(evidenceItem("Message-ID present", "The message includes a stable identifier for correlation and deduplication.", 0.74, "positive"));
  else {
    riskScore += 8;
    evidence.push(evidenceItem("Missing Message-ID", "No Message-ID header was found, reducing correlation confidence.", 0.48, "negative"));
  }
  if (headers.get("in-reply-to") || headers.get("references")) evidence.push(evidenceItem("Reply chain evidence", "In-Reply-To or References headers provide a direct relationship signal.", 0.93, "positive"));
  if (replyDomain && senderDomain && replyDomain !== senderDomain) {
    riskScore += 35;
    evidence.push(evidenceItem("Reply-To mismatch", `Reply-To resolves to ${replyDomain}, different from the sender domain ${senderDomain}.`, 0.91, "negative"));
  }
  if (urlDomains.length) {
    const externalDomains = urlDomains.filter((domain) => senderDomain && !domain.endsWith(senderDomain));
    if (externalDomains.length) {
      riskScore += 28;
      evidence.push(evidenceItem("External URL destination", `The message links to ${externalDomains.slice(0, 3).join(", ")}, outside the sender domain.`, 0.78, "negative"));
    } else evidence.push(evidenceItem("URL destination aligned", "Extracted links stay on the sender's domain.", 0.63, "positive"));
  }
  if (ips.length) {
    riskScore += Math.min(18, ips.length * 6);
    evidence.push(evidenceItem("Embedded IP indicators", `${ips.length} IP address${ips.length === 1 ? "" : "es"} were found in the source content.`, 0.67, "neutral"));
  }
  if (/(urgent|immediately|verify your|reset your password|wire transfer|invoice|payment required|credential)/i.test(lower)) {
    riskScore += 24;
    evidence.push(evidenceItem("Social-engineering language", "Urgency, payment, credential, or verification language appears in the subject or body.", 0.73, "negative"));
  }
  if (!recipients.length) evidence.push(evidenceItem("Recipient header unavailable", "No To, Cc, or Bcc address was parsed from the source.", 0.41, "neutral"));
  else evidence.push(evidenceItem("Recipient context parsed", `${recipients.length} recipient${recipients.length === 1 ? "" : "s"} were recovered from the headers.`, 0.72, "positive"));

  riskScore = Math.min(100, riskScore);
  const riskZone = riskScore >= 60 ? "dangerous" : riskScore >= 25 ? "uncertain" : "low";
  const structureSignals = [headers.get("from"), headers.get("subject"), headers.get("date")].filter(Boolean).length;
  const confidenceScore = clamp(0.62 + structureSignals * 0.08 + (headers.get("message-id") ? 0.08 : 0) - (riskZone === "uncertain" ? 0.08 : 0));
  const classification = /(invoice|payment|billing|wire|receipt)/i.test(lower)
    ? "Financial"
    : /(password|security|verify|login|account)/i.test(lower)
      ? "Security"
      : headers.get("in-reply-to") || headers.get("references")
        ? "Conversation/Thread"
        : "Professional";

  return {
    id: `email-${randomUUID()}`,
    filename: input.filename || `message-${index + 1}.eml`,
    sender,
    recipients,
    subject,
    timestamp: safeTimestamp,
    messageId: headers.get("message-id") || null,
    inReplyTo: headers.get("in-reply-to") || null,
    replyTo,
    classification,
    riskZone,
    riskScore,
    confidence: {
      score: confidenceScore,
      lowerBound: clamp(confidenceScore - 0.08),
      upperBound: clamp(confidenceScore + 0.06),
      modelVersion: "forensic-heuristics-v1",
    },
    evidence,
    urls,
    ips,
  };
}

export function buildForensicReport(name: string, inputs: EmailInput[]): ForensicReport {
  const emails = inputs.map(parseOne);
  const groups = new Map<string, ForensicEmail[]>();
  for (const email of emails) {
    const key = normalizedSubject(email.subject) || email.id;
    groups.set(key, [...(groups.get(key) ?? []), email]);
  }
  const dangerous = emails.filter((email) => email.riskZone === "dangerous");
  const uncertain = emails.filter((email) => email.riskZone === "uncertain");
  const riskScore = emails.length ? Math.round(emails.reduce((sum, email) => sum + email.riskScore, 0) / emails.length) : 0;
  const riskZone = dangerous.length ? "dangerous" : uncertain.length ? "uncertain" : "low";
  const findings = [
    { title: "Thread reconstruction", detail: `${groups.size} probable conversation group${groups.size === 1 ? "" : "s"} were inferred from normalized subjects and relationship headers.`, severity: groups.size < emails.length ? "info" : "warning" },
    { title: "Risk surface", detail: `${dangerous.length} dangerous, ${uncertain.length} uncertain, and ${emails.length - dangerous.length - uncertain.length} low-risk message${emails.length === 1 ? "" : "s"} were identified.`, severity: dangerous.length ? "danger" : uncertain.length ? "warning" : "info" },
    { title: "Source indicators", detail: `${new Set(emails.flatMap((email) => email.urls)).size} URLs and ${new Set(emails.flatMap((email) => email.ips)).size} IP indicators were extracted for review.`, severity: "info" },
  ] as ForensicReport["findings"];

  return {
    id: `report-${randomUUID()}`,
    name,
    createdAt: new Date(),
    status: "complete",
    emailCount: emails.length,
    threadCount: groups.size,
    riskScore,
    riskZone,
    summary: dangerous.length
      ? `Forensic review found ${dangerous.length} message${dangerous.length === 1 ? "" : "s"} with high-risk indicators. Review the evidence before treating any relationship as trusted.`
      : uncertain.length
        ? `Forensic review found ambiguous signals in ${uncertain.length} message${uncertain.length === 1 ? "" : "s"}. Manual review is recommended before closing the case.`
        : "Forensic review found no high-risk indicators in the uploaded source set. Confidence remains bounded by the available headers and content.",
    findings,
    emails,
  };
}
import { randomUUID } from "node:crypto";
import { createReadStream } from "node:fs";
import { mkdir, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import { Readable } from "node:stream";
import { Storage, type File } from "@google-cloud/storage";

const SIDECAR_ENDPOINT = "http://127.0.0.1:1106";
const LOCAL_UPLOAD_LIMIT = 50 * 1024 * 1024;
const localUploadGrants = new Map<string, {
  userId: string;
  objectPath: string;
  size: number;
  contentType: string;
  expiresAt: number;
}>();

type StoredFile =
  | { backend: "local"; filePath: string; contentType: string; size: number }
  | { backend: "gcs"; file: File };

type UploadTarget = { uploadURL: string; objectPath: string };

export const objectStorageClient = new Storage({
  credentials: {
    audience: "replit",
    subject_token_type: "access_token",
    token_url: `${SIDECAR_ENDPOINT}/token`,
    type: "external_account",
    credential_source: { url: `${SIDECAR_ENDPOINT}/credential`, format: { type: "json", subject_token_field_name: "access_token" } },
    universe_domain: "googleapis.com",
  },
  projectId: "",
});

export class ObjectNotFoundError extends Error {
  constructor() {
    super("Object not found");
    this.name = "ObjectNotFoundError";
  }
}

export class LocalUploadError extends Error {
  constructor(
    message: string,
    readonly statusCode: number,
  ) {
    super(message);
    this.name = "LocalUploadError";
  }
}

function parseObjectPath(path: string) {
  const parts = (path.startsWith("/") ? path : `/${path}`).split("/");
  if (parts.length < 3 || !parts[1] || !parts.slice(2).join("/")) throw new Error("Invalid object path");
  return { bucketName: parts[1], objectName: parts.slice(2).join("/") };
}

async function signObjectUrl(bucketName: string, objectName: string, method: "PUT" | "GET") {
  const response = await fetch(`${SIDECAR_ENDPOINT}/object-storage/signed-object-url`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      bucket_name: bucketName,
      object_name: objectName,
      method,
      expires_at: new Date(Date.now() + 15 * 60 * 1000).toISOString(),
    }),
    signal: AbortSignal.timeout(30_000),
  });
  if (!response.ok) throw new Error(`Failed to sign object URL (${response.status})`);
  const body = await response.json() as { signed_url?: string };
  if (!body.signed_url) throw new Error("Storage did not return a signed URL");
  return body.signed_url;
}

export class ObjectStorageService {
  private localRoot() {
    const value = process.env.LOCAL_UPLOAD_DIR;
    return value ? path.resolve(value) : null;
  }

  isLocalMode() {
    return this.localRoot() !== null;
  }

  private privateDir() {
    const value = process.env.PRIVATE_OBJECT_DIR;
    if (!value) throw new Error("PRIVATE_OBJECT_DIR is not configured");
    return value.replace(/\/+$/, "");
  }

  async createUploadTarget(input: {
    userId: string;
    size: number;
    contentType: string;
    origin: string;
  }): Promise<UploadTarget> {
    if (this.isLocalMode()) {
      if (input.size > LOCAL_UPLOAD_LIMIT) {
        throw new LocalUploadError("Local uploads are limited to 50 MB.", 413);
      }
      const objectPath = `/objects/${randomUUID()}`;
      const token = randomUUID();
      localUploadGrants.set(token, {
        userId: input.userId,
        objectPath,
        size: input.size,
        contentType: input.contentType,
        expiresAt: Date.now() + 15 * 60 * 1000,
      });
      return {
        uploadURL: new URL(`/api/storage/local-upload/${token}`, input.origin).toString(),
        objectPath,
      };
    }

    const fullPath = `${this.privateDir()}/uploads/${randomUUID()}`;
    const { bucketName, objectName } = parseObjectPath(fullPath);
    const uploadURL = await signObjectUrl(bucketName, objectName, "PUT");
    return { uploadURL, objectPath: this.normalizeObjectPath(uploadURL) };
  }

  normalizeObjectPath(rawPath: string) {
    if (!rawPath.startsWith("https://storage.googleapis.com/")) return rawPath;
    const pathname = new URL(rawPath).pathname;
    const privateDir = this.privateDir();
    if (!pathname.startsWith(`${privateDir}/`)) return pathname;
    return `/objects/${pathname.slice(privateDir.length + 1)}`;
  }

  async storeLocalUpload(token: string, userId: string, content: Buffer) {
    const grant = localUploadGrants.get(token);
    if (!grant || grant.expiresAt < Date.now()) {
      localUploadGrants.delete(token);
      throw new LocalUploadError("Upload link expired or not found.", 404);
    }
    if (grant.userId !== userId) throw new LocalUploadError("Upload owner mismatch.", 403);
    if (content.byteLength !== grant.size) throw new LocalUploadError("Uploaded file size did not match the request.", 400);

    const root = this.localRoot();
    if (!root) throw new LocalUploadError("Local storage is not enabled.", 404);
    const filename = grant.objectPath.slice("/objects/".length);
    const filePath = path.resolve(root, filename);
    if (path.dirname(filePath) !== root) throw new LocalUploadError("Invalid object path.", 400);
    await mkdir(root, { recursive: true });
    await writeFile(filePath, content, { flag: "wx" });
    localUploadGrants.delete(token);
  }

  async getFile(objectPath: string): Promise<StoredFile> {
    const root = this.localRoot();
    if (root) {
      if (!objectPath.startsWith("/objects/")) throw new ObjectNotFoundError();
      const filename = objectPath.slice("/objects/".length);
      if (!filename || filename.includes("/") || filename === "." || filename === "..") {
        throw new ObjectNotFoundError();
      }
      const filePath = path.resolve(root, filename);
      try {
        const metadata = await stat(filePath);
        if (!metadata.isFile()) throw new ObjectNotFoundError();
        return {
          backend: "local",
          filePath,
          contentType: "message/rfc822",
          size: metadata.size,
        };
      } catch {
        throw new ObjectNotFoundError();
      }
    }
    if (!objectPath.startsWith("/objects/")) throw new ObjectNotFoundError();
    const { bucketName, objectName } = parseObjectPath(`${this.privateDir()}/${objectPath.slice("/objects/".length)}`);
    const file = objectStorageClient.bucket(bucketName).file(objectName);
    const [exists] = await file.exists();
    if (!exists) throw new ObjectNotFoundError();
    return { backend: "gcs", file };
  }

  async download(storedFile: StoredFile) {
    const metadata = storedFile.backend === "local"
      ? { contentType: storedFile.contentType, size: storedFile.size }
      : await storedFile.file.getMetadata().then(([result]) => result);
    const stream = storedFile.backend === "local"
      ? Readable.toWeb(createReadStream(storedFile.filePath)) as ReadableStream
      : Readable.toWeb(storedFile.file.createReadStream()) as ReadableStream;
    const headers = new Headers({
      "Content-Type": String(metadata.contentType || "application/octet-stream"),
      "Cache-Control": "private, max-age=3600",
    });
    if (metadata.size) headers.set("Content-Length", String(metadata.size));
    return new Response(stream, { headers });
  }
}
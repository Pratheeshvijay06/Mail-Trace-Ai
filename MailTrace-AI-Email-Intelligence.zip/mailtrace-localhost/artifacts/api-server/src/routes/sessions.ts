import { Router, type IRouter } from "express";
import { ListSessionsResponse } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/requireAuth";
import { demoSessions } from "../lib/demo-data";

const router: IRouter = Router();

router.get("/sessions", requireAuth, (_req, res) => {
  res.json(ListSessionsResponse.parse(demoSessions));
});

export default router;
import { Router, type IRouter } from "express";
import {
  CreateInvestigationBody,
  CreateInvestigationResponse,
  DeleteInvestigationParams,
  GetInvestigationParams,
  GetInvestigationResponse,
  ListInvestigationsQueryParams,
  ListInvestigationsResponse,
} from "@workspace/api-zod";
import { requireAuth } from "../middlewares/requireAuth";
import { demoInvestigations, getInvestigation } from "../lib/demo-data";
import { db, mailtraceReportsTable } from "@workspace/db";
import { and, eq } from "drizzle-orm";
import { GetForensicReportResponse } from "@workspace/api-zod";
import { reportAsInvestigation, reportAsInvestigationRow } from "../lib/stored-mail";

const router: IRouter = Router();

router.get("/investigations", requireAuth, async (req, res) => {
  const query = ListInvestigationsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const term = query.data.q?.toLowerCase();
  const [storedRows] = await Promise.all([
    db.select({ report: mailtraceReportsTable.report })
      .from(mailtraceReportsTable)
      .where(eq(mailtraceReportsTable.userId, req.userId!)),
  ]);
  const stored = storedRows.flatMap((row) => {
    const result = GetForensicReportResponse.safeParse(row.report);
    return result.success ? [reportAsInvestigationRow(result.data)] : [];
  });
  const filtered = [...stored, ...demoInvestigations]
    .filter((item) => !term || item.name.toLowerCase().includes(term))
    .filter((item) => query.data.risk === "dangerous" ? item.dangerousCount > 0 : query.data.risk !== "low" || item.dangerousCount === 0)
    .slice(0, query.data.limit);
  res.json(ListInvestigationsResponse.parse(filtered));
});

router.post("/investigations", requireAuth, (req, res) => {
  const parsed = CreateInvestigationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const created = {
    id: `inv-${Date.now()}`,
    name: parsed.data.name,
    createdAt: new Date().toISOString(),
    status: "processing" as const,
    emailCount: 0,
    threadCount: 0,
    dangerousCount: 0,
    confidence: 0,
  };
  res.status(201).json(CreateInvestigationResponse.parse(created));
});

router.get("/investigations/:investigationId", requireAuth, async (req, res) => {
  const params = GetInvestigationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [storedRow] = await db.select({ report: mailtraceReportsTable.report })
    .from(mailtraceReportsTable)
    .where(and(eq(mailtraceReportsTable.id, params.data.investigationId), eq(mailtraceReportsTable.userId, req.userId!)))
    .limit(1);
  const storedReport = storedRow ? GetForensicReportResponse.safeParse(storedRow.report) : null;
  const investigation = storedReport?.success
    ? reportAsInvestigation(storedReport.data)
    : getInvestigation(params.data.investigationId);
  if (!investigation) {
    res.status(404).json({ error: "Investigation not found" });
    return;
  }
  res.json(GetInvestigationResponse.parse(investigation));
});

router.delete("/investigations/:investigationId", requireAuth, (req, res) => {
  const params = DeleteInvestigationParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  res.sendStatus(204);
});

export default router;
import { Readable } from "node:stream";
import express, { Router, type IRouter } from "express";
import { and, eq } from "drizzle-orm";
import { db, mailtraceUploadsTable } from "@workspace/db";
import { RequestUploadUrlBody, RequestUploadUrlResponse } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/requireAuth";
import { LocalUploadError, ObjectNotFoundError, ObjectStorageService } from "../lib/objectStorage";

const router: IRouter = Router();
const storage = new ObjectStorageService();

router.post("/storage/uploads/request-url", requireAuth, async (req, res) => {
  const parsed = RequestUploadUrlBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    const host = req.get("x-forwarded-host")?.split(",")[0]?.trim() || req.get("host");
    if (!host) throw new Error("Request host is unavailable");
    const protocol = req.get("x-forwarded-proto")?.split(",")[0]?.trim() || req.protocol;
    const { uploadURL, objectPath } = await storage.createUploadTarget({
      userId: req.userId!,
      size: parsed.data.size,
      contentType: parsed.data.contentType,
      origin: req.get("origin") || `${protocol}://${host}`,
    });
    res.json(RequestUploadUrlResponse.parse({
      uploadURL,
      objectPath,
      metadata: parsed.data,
    }));
  } catch (error) {
    if (error instanceof LocalUploadError) {
      res.status(error.statusCode).json({ error: error.message });
      return;
    }
    req.log.error({ err: error }, "Unable to create private upload URL");
    res.status(500).json({ error: "Unable to create upload URL" });
  }
});

router.put("/storage/local-upload/:token", requireAuth, express.raw({ type: "*/*", limit: "50mb" }), async (req, res) => {
  if (!storage.isLocalMode()) {
    res.status(404).json({ error: "Local uploads are not enabled" });
    return;
  }
  if (!Buffer.isBuffer(req.body)) {
    res.status(400).json({ error: "Expected a raw file upload" });
    return;
  }
  try {
    const token = Array.isArray(req.params.token) ? req.params.token[0] : req.params.token;
    await storage.storeLocalUpload(token, req.userId!, req.body);
    res.sendStatus(204);
  } catch (error) {
    if (error instanceof LocalUploadError) {
      res.status(error.statusCode).json({ error: error.message });
      return;
    }
    req.log.error({ err: error }, "Unable to store local upload");
    res.status(500).json({ error: "Unable to store uploaded file" });
  }
});

router.get("/storage/objects/*path", requireAuth, async (req, res) => {
  const rawPath = req.params.path;
  const objectPath = `/objects/${Array.isArray(rawPath) ? rawPath.join("/") : rawPath}`;
  try {
    const [ownedUpload] = await db.select({ id: mailtraceUploadsTable.id })
      .from(mailtraceUploadsTable)
      .where(and(eq(mailtraceUploadsTable.objectPath, objectPath), eq(mailtraceUploadsTable.userId, req.userId!)))
      .limit(1);
    if (!ownedUpload) {
      res.status(404).json({ error: "Object not found" });
      return;
    }
    const response = await storage.download(await storage.getFile(objectPath));
    res.status(response.status);
    response.headers.forEach((value, key) => res.setHeader(key, value));
    if (response.body) Readable.fromWeb(response.body as ReadableStream<Uint8Array>).pipe(res);
    else res.end();
  } catch (error) {
    if (error instanceof ObjectNotFoundError) {
      res.status(404).json({ error: "Object not found" });
      return;
    }
    req.log.error({ err: error }, "Unable to serve private object");
    res.status(500).json({ error: "Unable to serve object" });
  }
});

export default router;
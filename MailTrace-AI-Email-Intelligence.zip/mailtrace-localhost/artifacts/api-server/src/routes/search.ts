import { Router, type IRouter } from "express";
import {
  SearchIntelligenceQueryParams,
  SearchIntelligenceResponse,
} from "@workspace/api-zod";
import { requireAuth } from "../middlewares/requireAuth";
import { demoSearchResults } from "../lib/demo-data";

const router: IRouter = Router();

router.get("/search", requireAuth, (req, res) => {
  const query = SearchIntelligenceQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const term = query.data.q.toLowerCase();
  const results = demoSearchResults
    .filter((item) => `${item.title} ${item.subtitle}`.toLowerCase().includes(term))
    .slice(0, query.data.limit);
  res.json(SearchIntelligenceResponse.parse(results));
});

export default router;
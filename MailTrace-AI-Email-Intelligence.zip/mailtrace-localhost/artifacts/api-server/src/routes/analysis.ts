import { Router, type IRouter } from "express";
import {
  AnalyzeEmailsBody,
  AnalyzeEmailsResponse,
  GetForensicReportParams,
  GetForensicReportResponse,
  GetAnalysisJobParams,
  GetAnalysisJobResponse,
  type AnalysisJob,
} from "@workspace/api-zod";
import { and, eq } from "drizzle-orm";
import { db, mailtraceReportsTable, mailtraceUploadsTable } from "@workspace/db";
import { requireAuth } from "../middlewares/requireAuth";
import { buildForensicReport } from "../lib/forensics";

const router: IRouter = Router();
const analysisJobs = new Map<string, AnalysisJob>();

router.post("/emails/analyze", requireAuth, async (req, res) => {
  const parsed = AnalyzeEmailsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  try {
    const report = buildForensicReport(parsed.data.name, parsed.data.emails);
    await db.insert(mailtraceReportsTable).values({
      id: report.id,
      userId: req.userId!,
      name: report.name,
      status: report.status,
      emailCount: report.emailCount,
      report,
    });
    await db.insert(mailtraceUploadsTable).values(parsed.data.emails.map((email, index) => ({
      id: `upload-${report.id}-${index}`,
      reportId: report.id,
      userId: req.userId!,
      filename: email.filename || `message-${index + 1}.eml`,
      objectPath: email.objectPath || null,
      contentType: email.contentType || null,
      size: email.size || Buffer.byteLength(email.raw, "utf8"),
    })));
    const job = {
      id: `job-${report.id}`,
      investigationId: report.id,
      status: "complete" as const,
      total: parsed.data.emails.length,
      processed: parsed.data.emails.length,
      failed: 0,
      duplicates: 0,
      message: "Forensic report is ready.",
    };
    analysisJobs.set(job.id, job);
    res.status(202).json(AnalyzeEmailsResponse.parse(job));
  } catch (error) {
    req.log.error({ err: error }, "Unable to persist forensic report");
    res.status(500).json({ error: "Unable to store and analyze the uploaded email" });
  }
});

router.get("/analysis/jobs/:jobId", requireAuth, (req, res) => {
  const params = GetAnalysisJobParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const job = analysisJobs.get(params.data.jobId);
  if (!job) {
    res.status(404).json({ error: "Analysis job not found" });
    return;
  }
  res.json(GetAnalysisJobResponse.parse(job));
});

router.get("/analysis/reports/:reportId", requireAuth, async (req, res) => {
  const params = GetForensicReportParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db.select({ report: mailtraceReportsTable.report })
    .from(mailtraceReportsTable)
    .where(and(eq(mailtraceReportsTable.id, params.data.reportId), eq(mailtraceReportsTable.userId, req.userId!)))
    .limit(1);
  if (!row) {
    res.status(404).json({ error: "Forensic report not found" });
    return;
  }
  res.json(GetForensicReportResponse.parse(row.report));
});

export default router;
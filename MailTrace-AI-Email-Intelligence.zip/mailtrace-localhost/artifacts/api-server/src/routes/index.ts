import { Router, type IRouter } from "express";
import healthRouter from "./health";
import dashboardRouter from "./dashboard";
import investigationsRouter from "./investigations";
import analysisRouter from "./analysis";
import threadsRouter from "./threads";
import searchRouter from "./search";
import sessionsRouter from "./sessions";
import storageRouter from "./storage";

const router: IRouter = Router();

router.use(healthRouter);
router.use(dashboardRouter);
router.use(investigationsRouter);
router.use(analysisRouter);
router.use(threadsRouter);
router.use(searchRouter);
router.use(sessionsRouter);
router.use(storageRouter);

export default router;

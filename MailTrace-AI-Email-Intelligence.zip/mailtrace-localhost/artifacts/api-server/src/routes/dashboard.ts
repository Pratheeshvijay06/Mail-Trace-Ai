import { Router, type IRouter } from "express";
import { GetDashboardSummaryResponse } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/requireAuth";
import { demoSummary } from "../lib/demo-data";

const router: IRouter = Router();

router.get("/dashboard/summary", requireAuth, (_req, res) => {
  res.json(GetDashboardSummaryResponse.parse(demoSummary));
});

export default router;
import { Router, type IRouter } from "express";
import {
  GetThreadParams,
  GetThreadResponse,
  ListThreadsQueryParams,
  ListThreadsResponse,
} from "@workspace/api-zod";
import { requireAuth } from "../middlewares/requireAuth";
import { demoThreads, getThread } from "../lib/demo-data";
import { db, mailtraceReportsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { GetForensicReportResponse } from "@workspace/api-zod";
import { reportAsThreadDetails } from "../lib/stored-mail";

const router: IRouter = Router();

router.get("/threads", requireAuth, async (req, res) => {
  const query = ListThreadsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const term = query.data.q?.toLowerCase();
  const storedThreads = (await db.select({ report: mailtraceReportsTable.report })
    .from(mailtraceReportsTable)
    .where(eq(mailtraceReportsTable.userId, req.userId!)))
    .flatMap((row) => {
      const parsed = GetForensicReportResponse.safeParse(row.report);
      return parsed.success ? reportAsThreadDetails(parsed.data) : [];
    });
  const filtered = [...storedThreads, ...demoThreads]
    .filter((item) => !term || `${item.subject} ${item.identifier}`.toLowerCase().includes(term))
    .filter((item) => query.data.risk === "dangerous" ? item.riskZone === "dangerous" : query.data.risk !== "low" || item.riskZone === "low")
    .slice(0, query.data.limit);
  res.json(ListThreadsResponse.parse(filtered));
});

router.get("/threads/:threadId", requireAuth, async (req, res) => {
  const params = GetThreadParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const storedRows = await db.select({ report: mailtraceReportsTable.report })
    .from(mailtraceReportsTable)
    .where(eq(mailtraceReportsTable.userId, req.userId!));
  const storedThread = storedRows.flatMap((row) => {
    const result = GetForensicReportResponse.safeParse(row.report);
    return result.success ? reportAsThreadDetails(result.data) : [];
  }).find((thread) => thread.id === params.data.threadId);
  const thread = storedThread ?? getThread(params.data.threadId);
  if (!thread) {
    res.status(404).json({ error: "Thread not found" });
    return;
  }
  res.json(GetThreadResponse.parse(thread));
});

export default router;
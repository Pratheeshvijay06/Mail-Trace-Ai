import { integer, jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";

export const mailtraceReportsTable = pgTable("mailtrace_reports", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  name: text("name").notNull(),
  status: text("status").notNull().default("complete"),
  emailCount: integer("email_count").notNull().default(0),
  report: jsonb("report").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const mailtraceUploadsTable = pgTable("mailtrace_uploads", {
  id: text("id").primaryKey(),
  reportId: text("report_id").notNull(),
  userId: text("user_id").notNull(),
  filename: text("filename").notNull(),
  objectPath: text("object_path"),
  contentType: text("content_type"),
  size: integer("size").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type MailtraceReport = typeof mailtraceReportsTable.$inferSelect;
export type MailtraceUpload = typeof mailtraceUploadsTable.$inferSelect;
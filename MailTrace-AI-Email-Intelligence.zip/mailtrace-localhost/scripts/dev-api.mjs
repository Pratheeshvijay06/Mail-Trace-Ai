import { spawn, spawnSync } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";

const rootDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const apiDir = path.join(rootDir, "artifacts", "api-server");
const isWindows = process.platform === "win32";
const pnpmCommand = isWindows ? "pnpm.cmd" : "pnpm";
const env = { ...process.env, NODE_ENV: "development" };

const build = spawnSync(pnpmCommand, ["run", "build"], {
  cwd: apiDir,
  env,
  shell: isWindows,
  stdio: "inherit",
});

if (build.error) {
  console.error(`Could not start the API build: ${build.error.message}`);
  process.exit(1);
}
if (build.status !== 0) process.exit(build.status ?? 1);

const server = spawn(pnpmCommand, ["run", "start"], {
  cwd: apiDir,
  env,
  shell: isWindows,
  stdio: "inherit",
});

server.on("error", (error) => {
  console.error(`Could not start the API server: ${error.message}`);
  process.exitCode = 1;
});
server.on("close", (code) => {
  process.exitCode = code ?? 1;
});

for (const signal of ["SIGINT", "SIGTERM"]) {
  process.on(signal, () => server.kill(signal));
}

import { loadLocalEnv, rootDir, startPnpm } from "./local-env.mjs";

let env;
try {
  env = loadLocalEnv();
} catch (error) {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
}

for (const key of ["DATABASE_URL", "CLERK_PUBLISHABLE_KEY", "CLERK_SECRET_KEY", "VITE_CLERK_PUBLISHABLE_KEY"]) {
  if (!env[key] || env[key].includes("replace_me")) {
    console.error(`Set ${key} in .env.local before starting MailTrace.`);
    process.exit(1);
  }
}

delete env.PORT;
env.API_PORT ??= "8080";
env.VITE_PORT ??= "5173";
env.BASE_PATH ??= "/";
env.API_PROXY_TARGET ??= "http://127.0.0.1:8080";
env.LOCAL_UPLOAD_DIR ??= `${rootDir}/artifacts/api-server/.local-storage`;

startPnpm([
  "--parallel",
  "--filter", "@workspace/api-server",
  "--filter", "@workspace/mailtrace-ai",
  "run", "dev",
], env);

import { loadLocalEnv, startPnpm } from "./local-env.mjs";

let env;
try {
  env = loadLocalEnv();
} catch (error) {
  console.error(error instanceof Error ? error.message : error);
  process.exit(1);
}

if (!env.DATABASE_URL) {
  console.error("Set DATABASE_URL in .env.local before creating the local database tables.");
  process.exit(1);
}

startPnpm(["--filter", "@workspace/db", "run", "push"], env);

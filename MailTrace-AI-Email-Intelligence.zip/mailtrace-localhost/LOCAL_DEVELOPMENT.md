# Run MailTrace on your computer

MailTrace can run at `http://localhost:5173`. The local setup uses your PostgreSQL database and Clerk development keys, and stores uploaded email files in a private local folder. Replit continues to use App Storage unless `LOCAL_UPLOAD_DIR` is set.

## Requirements

- Node.js 20.19+ or 22.12+
- pnpm
- PostgreSQL
- A Clerk development application configured to allow `http://localhost:5173`

## Setup

1. Download or clone the project onto your computer.
2. Install Node.js 20.19+ or 22.12+ and pnpm, then from the project root install packages:

   ```sh
   pnpm install
   ```

3. Create a PostgreSQL database named `mailtrace` (or choose another name).
4. Copy `.env.local.example` to `.env.local`. Update `DATABASE_URL` with your local database URL, and add your Clerk development keys. Keep `.env.local` private; it is ignored by Git.
5. Create the database tables:

   ```sh
   node scripts/local-db-push.mjs
   ```

6. Start the API and website together:

   ```sh
   node scripts/local-dev.mjs
   ```

7. Open `http://localhost:5173`.

The local upload folder is `artifacts/api-server/.local-storage/`. It is not served as a public static directory. Use the Clerk sign-in on localhost to access the protected workspace.

## Notes

- `localhost` works only on your computer. To let other people use the website, publish it with Public access.
- The script starts the API on port `8080` and Vite on port `5173`. Set `API_PORT` or `VITE_PORT` in `.env.local` to change these ports. The Node scripts work on Windows, macOS, and Linux.
- Local database contents and email files are separate from Replit's database and App Storage.
